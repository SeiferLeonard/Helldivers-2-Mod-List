Dagger Apex v1.1.1 — Dagger only / Future-Proofed

Baseline
- Built directly from the confirmed working Dagger Apex v1.0.0 package.
- No SAI source or SAI resource is included.
- Gameplay targets are unchanged.

Dagger changes
- Standard damage: 1000
- Durable damage: 1000
- Armor penetration: AP3
- Demolition strength: 10

Future-proofing
- Build compatibility profile for Steam build 25480438 / EXE 1.8.46015.0.
- Runtime table discovery with live record-count/stride derivation.
- DamageInfo AP-layout discovery from a distribution fingerprint.
- Dagger beam target selection uses multi-field candidate scoring instead of a short non-unique byte fingerprint.
- BeamType enum is treated as a hint, not sole identity.
- Guarded writes, pre-write revalidation, read-back verification, and rollback.
- Runtime relocation detection and periodic re-discovery/reapply.
- Bounded scans and diagnostic candidate scores.
- Unknown builds refuse memory writes until a new compatibility profile is added.

Compatibility
- Helldivers 2 build: Steam 25480438
- EXE: 1.8.46015.0
- EXE SHA-256: f5fee03dcfdb2e553a4752c283590950ac13316b376d8196aa556ff0400d5f06
- lua51.dll SHA-256: 2c8720c9f446c848436ad993b1a88099d76f0b0b09df53689719b797c3039ce7
- Requires: Bingus Shared Loader v17 / API 1
- Loader is not bundled.

Testing
- Gameplay values are inherited from the confirmed working v1.0.0 Dagger baseline.
- v1.1.1 future-proofing is not yet independently game-verified; test this build before moving on.

Internal addon resource
- mods/localdev/dagger_apex
- No SAI resources are present.
