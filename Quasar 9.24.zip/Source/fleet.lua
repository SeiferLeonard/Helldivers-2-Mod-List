-- Bounded management of local-carried and unattached authoritative Quasars.
local M={}
function M.new()return {items={},cursor=0,count=0}end
function M.step(f,api,game,reader,policy,now,write,release,event,log)
    local failures=0
    if not f.next_discovery or now>=f.next_discovery then
        f.next_discovery=now+0.5
        local ok,rows,cursor=pcall(reader.discover,api,game,f.cursor)
        if ok then
            f.cursor=cursor;f.discovery_error=nil
            for _,token in ipairs(rows) do
                local key=token.id..':'..token.generation
                if not f.items[key] and f.count<8 then
                    f.items[key]={token=token,policy=policy.new()};f.count=f.count+1
                end
            end
        else
            failures=failures+1
            f.next_discovery=now+2
            local reason=tostring(rows)
            if reason~=f.discovery_error then event('DISCOVERY_WAIT '..reason);f.discovery_error=reason end
        end
    end
    for key,item in pairs(f.items) do
      if not item.next_snapshot or now>=item.next_snapshot then
        local ok,row,reason=pcall(reader.snapshot,api,game,item.token)
        if not ok then failures=failures+1;reason=tostring(row);row=nil end
        item.next_snapshot=not ok and now+0.5 or nil
        local function emit(s)event('id='..key..' '..s)end
        policy.step(item.policy,row,now,write,release,emit)
        if row then
            local prefix='phase='..item.policy.phase..' '
            local line=prefix..reader.format(row);local discrete=prefix..reader.format(row,true)
            if not item.last_emit or discrete~=item.last_key or (line~=item.last_line and now-item.last_emit>=0.5) or now-item.last_emit>=30 then
                log(line);item.last_emit=now;item.last_key=discrete;item.last_line=line
            end
            item.missing_since=nil
        elseif item.policy.lease then
            if reason~=item.last_reason then emit('READ_WAIT '..tostring(reason));item.last_reason=reason end
        elseif ok or (item.missing_since and now-item.missing_since>=5) then
            f.items[key]=nil;f.count=f.count-1
        else item.missing_since=item.missing_since or now end
      end
    end
    return failures
end
function M.stop(f,policy,release)
    local clean=true
    for _,item in pairs(f.items) do
        local ok,result=pcall(policy.stop,item.policy,release)
        if not ok or not result then clean=false end
    end
    return clean
end
return M
