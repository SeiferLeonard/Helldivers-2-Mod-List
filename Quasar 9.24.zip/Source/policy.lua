-- One policy per weapon. Native Heat performs all timing and limiting.
local M={}
function M.new()return {phase='observe'}end
function M.step(p,r,now,write,release,event)
    -- Preserve our own request across a verified local drop/pickup.
    if p.lease and r and r.id==p.lease.id and r.generation==p.lease.generation
        and r.actor_id==p.lease.actor_id and r.actor_generation==p.lease.actor_generation then
        p.lease=r
    end
    if p.lease and (not r or r.key~=p.lease.key or r.actor_id~=p.lease.actor_id) then
        local ok,why=release(p.lease)
        if not ok then p.phase='cleanup_pending';return end
        event('RELEASE '..tostring(why));p.lease=nil
    end
    if not r then p.key=nil;p.away_since=nil;p.phase='observe';return end
    if p.key~=r.key or p.actor_id~=r.actor_id then p.key=r.key;p.actor_id=r.actor_id;p.away_since=nil;p.cancelled=false end
    local present=r.state_presence=='present'
    local native=r.trigger~=0 or (present and (r.state~=0 or r.input~=0))
    local away=r.equipped==false and (r.grounded or (r.slot and r.slot>0))
    local inactive=r.trigger==0 and ((present and r.state==0 and r.input==0) or r.state_presence=='absent')
    if r.equipped or r.overheated==1 then p.cancelled=false end
    if p.lease and native then
        event('HANDOFF native_state='..tostring(r.state));p.lease=nil;p.phase='observe'
    end
    if p.lease and (r.overheated==1 or not r.in_update) then
        local ok,why=release(p.lease)
        if not ok then p.phase='cleanup_pending';return end
        event('RELEASE '..tostring(why));p.lease=nil
    end
    if p.lease then
        if r.drive==0 then
            p.lease=nil;p.cancelled=true;p.away_since=nil;p.phase='cancelled'
            event('CANCEL native_cleared_drive')
        else p.phase='holding' end
        return
    end
    if r.overheated~=0 or r.heat~=0 then p.phase='cooldown';p.away_since=nil;return end
    if p.cancelled then p.phase='cancelled';return end
    if away and inactive and r.in_update and r.drive==0 and r.request==0 then
        p.away_since=p.away_since or now;p.phase='settling'
        if now-p.away_since>=0.25 then
            p.lease=r
            local ok,why=write(r,1)
            if not ok then error('activate_failed '..tostring(why)) end
            p.phase='holding';event('DRIVE_ON scope='..(r.grounded and 'ground' or 'holstered'))
        end
    else p.away_since=nil;p.phase='waiting_for_holster' end
end
function M.stop(p,release)
    if not p.lease then return true end
    local ok,why=release(p.lease);if ok then p.lease=nil end;return ok,why
end
return M
