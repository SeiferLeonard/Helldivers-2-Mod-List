return function(create_api,reader,policy,signatures,fleet,settings,enhanced)
    if rawget(_G,'QuasarAutoChargePrototype') then return end
    local state={version='0.2.2',samples=0,errors=0,writes=0}
    rawset(_G,'QuasarAutoChargePrototype',state)
    local base=os.getenv('LOCALAPPDATA')
    local file=base and io.open(base..'/QuasarAutoChargePrototype.log','a')
    if not file then state.status='log_open_failed';print('[QuasarPrototype] log_open_failed');return end
    local api,game,start,closed,last_cleanup_error
    local p=policy.new()
    local f=fleet and fleet.new()
    local setting_state=settings and settings.new(enhanced)
    local function log(message)
        local ok=pcall(function()
            assert(file:write(string.format('t=%.3f %s\n',api and (api.time()-start) or 0,message)))
            assert(file:flush())
        end)
        return ok
    end
    local function close()if not closed then closed=true;file:close() end end
    local function release(token)return reader.release(api,game,token)end
    local function cleanup()
        if not api or not game then return true end
        local ok,result,why=pcall(function()
            local clean
            if f then clean=fleet.stop(f,policy,release) else clean=policy.stop(p,release) end
            if settings and not settings.stop(setting_state,api,function(s)log('EVENT '..s)end) then clean=false end
            return clean
        end)
        if not ok or not result then
            local message=tostring(why or result)
            if message~=last_cleanup_error then print('[QuasarPrototype] cleanup_pending '..message) end
            last_cleanup_error=message;return false
        end
        last_cleanup_error=nil
        return true
    end
    local ok,why=pcall(function()
        assert(log('SESSION version=0.2.2 wall_time='..os.date('%Y-%m-%dT%H:%M:%S')..' variant='..(enhanced and 'enhanced' or 'charge_only')),'log_write_failed')
        local loader=rawget(_G,'CowboyBingusModLoader')
        assert(loader and loader.api==1 and loader.version>=16,'Bingus_Shared_Loader_v15_required')
        api=create_api();start=api.time();game=assert(api.module('game.dll'))
        local exe=assert(api.module(nil));local eh,gh=api.module_hash(exe),api.module_hash(game)
        assert(eh=='F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06' and
            gh=='2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E','unsupported_game_build')
        for _,s in ipairs(signatures) do
            local expected=s[2]:gsub('..',function(v)return string.char(tonumber(v,16))end)
            assert(api.read(game+s[1],#expected)==expected,'unsupported_native_code')
        end
        assert(log('BUILD exe_sha256='..eh..' game_sha256='..gh),'log_write_failed')
        assert(log('READY sample_interval=0.05s curve_interval=0.5s heartbeat=30s; max_tracked=8; ground_and_holstered; enhanced='..tostring(enhanced==true)),'log_write_failed')
        assert(type(update)=='function','update_unavailable')
        local previous,previous_shutdown=update,shutdown
        local last_sample,last_emit,last_line,last_key,disabled,stopped,next_cleanup
        local function event(s)assert(log('EVENT '..s),'log_write_failed')end
        local function write(r,v)
            local success,reason=reader.set_drive(api,r,v)
            if success then state.writes=state.writes+1 end;return success,reason
        end
        local function sample()
            if stopped then return end
            local now=api.time()
            if last_sample and now-last_sample<0.05 then return end
            last_sample=now;state.samples=state.samples+1
            if disabled then
                if next_cleanup and now<next_cleanup then return end
                next_cleanup=now+1
                if cleanup() then stopped=true end
                return
            end
            if settings then
                settings.step(setting_state,api,game,now,event)
                if setting_state.failed and (not setting_state.next_cleanup or now>=setting_state.next_cleanup) then
                    setting_state.next_cleanup=now+2;settings.stop(setting_state,api,event)
                end
            end
            if f then
                state.errors=state.errors+fleet.step(f,api,game,reader,policy,now,write,release,event,function(s)assert(log(s),'log_write_failed')end)
                state.status='tracking';return
            end
            local worked,r,reason=pcall(reader.snapshot,api,game)
            if not worked then state.errors=state.errors+1;reason=tostring(r);r=nil end
            policy.step(p,r,now,write,release,event)
            local prefix='phase='..p.phase..' '
            local line=prefix..(r and reader.format(r) or ('status=read_wait reason='..tostring(reason)))
            local key=prefix..(r and reader.format(r,true) or ('status=read_wait reason='..tostring(reason)))
            if not last_emit or key~=last_key or (line~=last_line and now-last_emit>=0.5) or now-last_emit>=30 then
                assert(log(line),'log_write_failed');last_emit=now;last_line=line;last_key=key
            end
            state.status=p.phase
        end
        local function after(called,...)
            if not called then
                stopped=true;cleanup();log('END original_update_failed');close();error((...),0)
            end
            local worked,err=pcall(sample)
            if not worked then
                disabled=true;state.status='disabled';local clean=cleanup()
                log('DISABLED '..tostring(err)..' cleanup='..tostring(clean));if clean then stopped=true end
            end
            return ...
        end
        update=function(...)return after(pcall(previous,...))end
        shutdown=function(...)
            stopped=true;local clean=cleanup()
            log(string.format('END samples=%u read_errors=%u activation_writes=%u cleanup=%s',state.samples,state.errors,state.writes,tostring(clean)))
            close();if previous_shutdown then return previous_shutdown(...) end
        end
        state.status='ready'
    end)
    if not ok then cleanup();state.status='disabled';log('DISABLED '..tostring(why));close() end
end
