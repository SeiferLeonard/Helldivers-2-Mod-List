-- Hash-locked native layout. See SOURCES.md; no field names inferred from dumps.
local ffi,bit=require('ffi'),require('bit')
local M={}
local function u(b,o)
    local v=ffi.new('uint32_t[1]');ffi.copy(v,b:sub(o+1,o+4),4);return tonumber(v[0])
end
local function f(b,o)
    local v=ffi.new('float[1]');ffi.copy(v,b:sub(o+1,o+4),4)
    local n=tonumber(v[0]);assert(n==n and n>=0 and n<=10000,'invalid_heat_float');return n
end
local QUASAR='\x7e\xc4\x9c\x61\x96\x12\xa6\x35'
local AVATAR='\x97\xfa\x4d\x29\x4d\x33\x1c\x4d'
-- token selects a previous weapon for conditional cleanup, always through fresh maps.
function M.snapshot(api,game,token)
    local cleanup=token and not token.track
    local guards={}
    local function read(a,n,guard)
        local b=assert(api.read(a,n),'read_unavailable');assert(#b==n,'short_read')
        if guard then guards[#guards+1]={a,b} end;return b
    end
    local function ptr(b)return assert(api.pointer(b),'pointer_unavailable')end
    local function root(r)return ptr(read(game+r,8,true))end
    local function lookup(manager,offset,id,optional)
        local h=read(manager+offset,20,true);local cap=u(h,8)
        assert(cap>0 and cap<=1048576 and bit.band(cap,cap-1)==0,'map_capacity')
        local base=ptr(h)
        local hash=tonumber(ffi.cast('uint32_t',ffi.new('uint64_t',id)*ffi.new('uint64_t',u(h,16))))
        for p=0,math.min(cap,128)-1 do
            local row=read(base+bit.band(hash+p,cap-1)*8,8,true)
            if u(row,0)==id and u(row,4)~=0xffffffff then
                local index=u(row,4);assert(index<262144,'map_index');return index
            end
            if u(row,0)==u(h,12) then break end
        end
        if optional then return nil end;error('component_missing')
    end
    local function entity(manager,offset,index)
        return ptr(read(ptr(read(manager+offset,8,true))+index*8,8,true))
    end
    local function identity(address,resource,id)
        local b=read(address,24,true)
        assert(b:sub(1,8)==resource and u(b,8)==id and bit.band(b:byte(21),1)==1,'entity_identity')
        return b
    end
    local local_id,avatar,inventory,slot,current,mission
    if not cleanup then
        local mode=read(root(0x33266a0),0x44,true);mission=u(mode,0x40)
        if u(mode,8)==0 or mission<1 or mission>7 then return nil,'waiting_for_mission' end
        local pm=root(0x3326468);local counts=read(pm+0x84,8,true)
        assert(u(counts,0)>0 and u(counts,0)<=4 and u(counts,4)>0 and u(counts,4)<=4,'waiting_for_player')
        assert(bit.band(read(ptr(read(pm+0xe8,8,true)),24,true):byte(21),1)==1,'waiting_for_player')
        local unit=u(read(pm+0x3a8,4,true),0);assert(unit~=0x7fff,'waiting_for_avatar')
        local em=root(0x346bf98);local ei=lookup(em,0xf22ec8,unit)
        avatar=read(em+0xf32f18+ei*24,24,true);local_id=u(avatar,8)
        assert(avatar:sub(1,8)==AVATAR and bit.band(avatar:byte(21),1)==1,'local_avatar_identity')
        local eq=root(0x3326738);local qi=lookup(eq,40,local_id);assert(qi<4096,'equipment_index')
        assert(read(entity(eq,64,qi),24,true)==avatar,'equipment_identity')
        inventory=read(ptr(read(eq+80,8,true))+qi*48,48,true);slot=u(inventory,28)
        assert(slot<=6,'unsupported_equipment_slot')
        local offsets={[1]=0,[2]=4,[3]=8,[4]=16,[5]=16,[6]=12}
        current=offsets[slot] and u(inventory,offsets[slot]) or 0
    end
    local id=token and token.id or u(inventory,8)
    local wm=root(0x3326ce0);local wi=lookup(wm,48,id,true)
    if not wi then return nil,'no_support_weapon' end
    assert(wi<16384,'weapon_index')
    local address=entity(wm,72,wi);local eb=read(address,24,true)
    if eb:sub(1,8)~=QUASAR or u(eb,8)~=id then return nil,'not_quasar' end
    assert(bit.band(eb:byte(21),1)==1,'weapon_not_authority')
    local generation=u(eb,16)
    if token and generation~=token.generation then return nil,'old_identity_gone' end
    local net=read(ptr(read(wm+96,8,true))+wi*12,4,true)
    assert(u(net,0)==2,'unsupported_fire_mode')
    local am=root(0x3326dc0);local ai=lookup(am,32,id);assert(ai<4096,'attachment_index')
    local holder=u(read(ptr(read(am+64,8,true))+ai*48+4,4,true),0)
    if cleanup then
        if holder~=token.holder then return nil,'ownership_changed' end
    elseif holder~=0 and holder~=local_id then return nil,'not_local_holder' end
    -- Unattached weapons still run native Heat/Control. Inspect the local
    -- avatar's slots as well, so a drop transition cannot look prematurely idle.
    local actor_id=holder~=0 and holder or (local_id or token.actor_id)
    local sm=root(0x3326420);local si=lookup(sm,48,actor_id);assert(si<4096,'state_index')
    local actor_address=entity(sm,72,si);local actor=identity(actor_address,AVATAR,actor_id)
    if cleanup then
        if u(actor,16)~=token.actor_generation then return nil,'old_actor_gone' end
    else assert(actor==avatar,'state_actor_identity') end
    local runtime=ptr(read(sm+96,8,true))+si*464
    local found,state_slot
    local records={}
    for i=0,4 do
        records[i]=read(runtime+i*80,8,true)
        if u(records[i],0)==id then assert(not found,'ambiguous_state_slot');found=true;state_slot=i end
    end
    -- Reject redirection rather than guessing its ownership semantics.
    local invalid=u(read(game+0x3483c34,4,true),0)
    if found then assert(u(records[state_slot],4)==invalid,'redirected_state_slot') end
    for i=0,4 do
        assert(i==state_slot or u(records[i],4)~=id,'aliased_state_slot')
    end
    -- Equipment switching unbinds the old entity (0x9aabf5 -> 0x785d10).
    -- A complete, guarded scan with no base/redirect match is NOT a failed read.
    -- Do not manufacture state=0 or reuse the slot now occupied by another gun.
    local state,input
    if found then
        local state_word=u(read(ptr(read(sm+104,8,true))+si*4,4,true),0)
        state=bit.band(bit.rshift(state_word,state_slot*3),7)
        input=read(ptr(read(sm+88,8,true))+si*32+state_slot,1,true):byte(1)
        assert(input<=1,'unsupported_state_request')
    end
    local cm=root(0x3326660);local ci=lookup(cm,40,id);assert(ci<16384,'control_index')
    assert(entity(cm,64,ci)==address,'control_identity')
    local trigger=read(ptr(read(cm+88,8,true))+ci,1,true):byte(1);assert(trigger<=1,'trigger_invalid')
    local count=u(read(cm+24,4,true),0);assert(count<=16384,'control_count')
    local hm=root(0x3326d48);local hi=lookup(hm,40,id);assert(hi<16384,'heat_index')
    assert(entity(hm,64,hi)==address,'heat_identity')
    local hr=read(ptr(read(hm+80,8,true))+hi*72+12,4)
    local hn=read(ptr(read(hm+88,8,true))+hi*12+4,6,true)
    local drive_address=ptr(read(hm+72,8,true))+hi
    local drive=read(drive_address,1):byte(1);assert(drive<=1,'drive_invalid')
    local overheat,request=hn:byte(5),hn:byte(6)
    assert(overheat<=1 and request<=1,'heat_flags_invalid')
    local row={id=id,generation=generation,holder=holder,actor_id=actor_id,actor_generation=u(actor,16),grounded=holder==0,
        key=string.format('%u:%u:%u:%u',id,generation,holder,u(actor,16)),
        slot=slot,state_presence=found and 'present' or 'absent',
        state_slot=state_slot,state=state,input=input,trigger=trigger,
        charge=f(hr,0),heat=f(hn,0),overheated=overheat,request=request,drive=drive,
        in_update=ci<count,drive_address=drive_address,guards=guards,mission=mission}
    -- Explicit false matters: cleanup snapshots have unknown selection (nil).
    if not cleanup then row.equipped=holder~=0 and current==id end
    assert(M.matches(api,guards),'snapshot_changed');return row
end
function M.matches(api,guards)
    for _,g in ipairs(guards) do if api.read(g[1],#g[2])~=g[2] then return false end end
    return true
end
function M.set_drive(api,row,value)
    if value==1 and row.equipped~=false then return false,'not_holstered_or_grounded' end
    local present_idle=row.state_presence=='present' and row.state==0 and row.input==0
    local absent=row.state_presence=='absent'
    -- Release can clear our own request on an unbound weapon. Activation also
    -- requires current local selection to positively identify another item.
    local absent_idle=absent and (value==0 or (row.equipped==false and (row.grounded or (row.slot and row.slot>0))))
    if row.trigger~=0 or not (present_idle or absent_idle) then return false,'native_active_or_unresolved' end
    if value==1 and (row.overheated~=0 or row.heat~=0 or not row.in_update) then return false,'not_cooled' end
    if not M.matches(api,row.guards) then return false,'snapshot_changed' end
    if not api.write_byte(row.drive_address,row.drive,value) then return false,'drive_write_failed' end
    return true
end
-- Bounded registry discovery: 32 Heat entities per call, no address-space scan.
-- Candidates are independently resolved/validated by snapshot before any write.
function M.discover(api,game,cursor)
    -- assert returns ALL arguments on success; only return the bytes here.
    -- Otherwise api.pointer(read(...)) receives the error string as its offset.
    local function read(a,n)return (assert(api.read(a,n),'discovery_read_unavailable'))end
    local mode=assert(api.pointer(read(game+0x33266a0,8)),'discovery_mission')
    local mb=read(mode,0x44);local mission=u(mb,0x40)
    if u(mb,8)==0 or mission<1 or mission>7 then return {},0 end
    local rb=read(game+0x3326d48,8);local manager=assert(api.pointer(rb),'discovery_root')
    local count_bytes=read(manager+16,4);local count=u(count_bytes,0)
    assert(count<=4096,'discovery_count')
    if count==0 then return {},0 end
    local pb=read(manager+64,8);local pointers=assert(api.pointer(pb),'discovery_entities')
    cursor=cursor or 0;if cursor>=count then cursor=0 end
    local rows={}
    for i=cursor,math.min(cursor+31,count-1) do
        local eb=read(pointers+i*8,8);local address=assert(api.pointer(eb),'discovery_entity')
        local b=read(address,24)
        if b:sub(1,8)==QUASAR and bit.band(b:byte(21),1)==1 then
            rows[#rows+1]={track=true,id=u(b,8),generation=u(b,16)}
        end
    end
    assert(read(game+0x3326d48,8)==rb and read(manager+16,4)==count_bytes and read(manager+64,8)==pb,'discovery_changed')
    return rows,cursor+32>=count and 0 or cursor+32
end
function M.release(api,game,token)
    local ok,row,why=pcall(M.snapshot,api,game,token)
    if not ok then return false,tostring(row) end
    if not row then return true,why end -- destroyed/replaced/transferred; never follow another owner.
    if row.trigger~=0 or (row.state_presence=='present' and (row.state~=0 or row.input~=0)) then return true,'native_handoff' end
    if row.drive==0 then return true,'already_cleared' end
    return M.set_drive(api,row,0)
end
function M.format(r,discrete)
    if not r then return '' end
    local s=string.format('weapon=%s equipped=%s grounded=%s slot=%s state_presence=%s state_slot=%s state=%s input=%s trigger=%u drive=%u request=%u overheated=%u in_update=%s',
        r.key,tostring(r.equipped),tostring(r.grounded),tostring(r.slot),r.state_presence,tostring(r.state_slot),tostring(r.state),tostring(r.input),r.trigger,r.drive,r.request,r.overheated,tostring(r.in_update))
    if not discrete then s=s..string.format(' charge=%.2f heat=%.2f',r.charge,r.heat) end
    return s
end
return M
