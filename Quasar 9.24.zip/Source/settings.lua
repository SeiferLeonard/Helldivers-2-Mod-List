-- Enhanced option only. Direct native pointer tables; no address-space scan.
return function(records)
    local M={}
    local function bytes(s)return (s:gsub('..',function(v)return string.char(tonumber(v,16))end))end
    local original,projectile,explosion={},bytes(records.projectile),bytes(records.explosion)
    original[383]=bytes(records['383']);original[384]=bytes(records['384'])
    local plans={{id=383,offset=4,old='\xd0\x07\0\0\xd0\x07\0\0',new='\x80\x0c\0\0\x80\x0c\0\0'},
        {id=384,offset=28,old='\x1e\0\0\0',new='\x28\0\0\0'}}
    local function record(api,game,base,id,size)
        local slot=game+base+id*8;local raw=assert(api.read(slot,8),'settings_pointer_unavailable')
        local address=assert(api.pointer(raw),'settings_not_loaded')
        return {slot=slot,pointer=raw,address=address,data=assert(api.read(address,size),'settings_read_unavailable')}
    end
    local function same(api,r)
        local raw=api.read(r.slot,8)
        if not raw then return nil end
        return raw==r.pointer
    end
    local function changed(data,plan)return data:sub(1,plan.offset)..plan.new..data:sub(plan.offset+#plan.new+1)end
    local function validate_links(api,game)
        local p=record(api,game,0x37c7670,133,272)
        assert(p.data==projectile,'quasar_projectile_changed')
        local e=record(api,game,0x37cc920,67,152)
        -- Explosion ShakeAssets is a relocated pointer, not a resource hash.
        assert(e.data:sub(1,40)==explosion:sub(1,40) and e.data:sub(49)==explosion:sub(49),'quasar_explosion_changed')
        return p,e
    end
    function M.new(enabled)return {enabled=enabled,leases={},status=enabled and 'waiting' or 'original'}end
    function M.step(s,api,game,now,event)
        if not s.enabled or s.failed or (s.next_check and now<s.next_check) then return end
        s.next_check=now+2
        local ok,why=pcall(function()
            local p,e=validate_links(api,game)
            local current={}
            -- Validate BOTH records before either write.
            for i,plan in ipairs(plans) do
                local r=record(api,game,0x37c60c0,plan.id,76);local lease=s.leases[i]
                if lease then
                    local unchanged=same(api,lease)
                    assert(unchanged~=nil,'settings_pointer_unavailable')
                    if not unchanged then s.leases[i]=nil;lease=nil end
                end
                local expected=original[plan.id]
                assert((not lease and r.data==expected) or (lease and r.data==changed(expected,plan)),'quasar_damage_conflict_'..plan.id)
                current[i]=r
            end
            for i,plan in ipairs(plans) do
                local r=current[i]
                if not s.leases[i] then
                    assert(same(api,p) and same(api,e) and same(api,current[1]) and same(api,current[2]),'settings_pointer_changed')
                    assert(api.read(r.address,76)==r.data,'settings_record_changed')
                    s.leases[i]=r -- journal before any uncertain write result
                    assert(api.write_setting(r.address+plan.offset,plan.old,plan.new),'settings_write_failed')
                end
            end
            if s.status~='applied' then event('ENHANCEMENT_APPLIED direct=3200 durable=3200 explosion_demolition=40') end
            s.status='applied'
        end)
        if not ok then
            local reason=tostring(why)
            if reason:find('not_loaded',1,true) or reason:find('unavailable',1,true) then
                s.retries=(s.retries or 0)+1
                if s.last_wait~=reason then event('ENHANCEMENT_WAIT '..reason);s.last_wait=reason end
                if s.retries>15 then s.next_check=now+10 end
                s.status='waiting';return
            end
            s.failed=true;s.status='failed';event('ENHANCEMENT_DISABLED '..reason)
            M.stop(s,api,event)
        end
    end
    function M.stop(s,api,event)
        local clean=true
        for i,r in pairs(s.leases) do
            local plan=plans[i]
            local unchanged=same(api,r)
            if unchanged==nil then clean=false
            elseif not unchanged then s.leases[i]=nil -- old table was unloaded; never follow freed storage
            else
                local data=api.read(r.address,76)
                if data==original[plan.id] then s.leases[i]=nil
                elseif data==changed(original[plan.id],plan) then
                    if api.write_setting(r.address+plan.offset,plan.new,plan.old) then s.leases[i]=nil
                    else clean=false end
                elseif data then
                    -- A different mod has changed the record; do not undo its work.
                    s.leases[i]=nil;event('ENHANCEMENT_RELEASE_CONFLICT type='..plan.id)
                else clean=false end
            end
        end
        return clean
    end
    return M
end
