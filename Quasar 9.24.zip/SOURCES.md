# Sources and evidence

## v0.2.2 — build 25480438 (2026-09-24)

New EXE 1.8.46015.0 SHA-256:
`f5fee03dcfdb2e553a4752c283590950ac13316b376d8196aa556ff0400d5f06`.
New `game.dll` SHA-256:
`2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e`.
Read-only `analysis/build-25480438/scout.json` confirms all fourteen base
and three optional enhancement signatures at their prior RVAs with identical
bytes, plus nonzero mission/player/component root slots. Two signatures also
occur elsewhere, so their original RVAs remain explicit checks. Read-only
`analysis/build-25480438/tables.json` confirms damage records 383/384 and
projectile 133 byte for byte at the prior pointer-map slots. Explosion 67
matches after excluding its relocated ShakeAssets pointer at bytes 40–47.
No process writes were made by either probe. Old records/signatures remain
build-labeled historical evidence. The 0.2.2 package has not been deployed
or gameplay-tested on the new build.

## v0.2.1 — discovery argument regression

Actual v0.2.0 session at2026-09-23T23:44:46 (`analysis/failed-v0.2.0-session.log`)
loaded enhanced successfully, then logged `attempt to compare string with number` in
the Windows pointer parser. All378 seconds ended with activation_writes=0. User confirmed
demolition works and holstered charging does not; new Titan damage not tested.

Cause: discovery's `read()` returned `assert(bytes, error_message)`, which returns both
arguments on success. `api.pointer(read(...))` therefore passed the error string as the
optional offset. Single-argument mocks in the earlier probe/replay silently ignored it.
The fix returns exactly one value, without changing offsets, native flags or enhanced values.
Discovery failures now also increment the session error counter.

Regression reproduced using the real `windows_api.lua` pointer parser and existing
live-ground capture before changing the reader, then passed after the single-result fix.
Real snapshot replays and the read-only live probe now use that production parser.
Both package variants passed all offline tests; v0.2.1 was not deployed/gameplay-tested here.

## v0.2.0 — ground charging and optional enhanced settings (2026-09-23)

Same supported hashes as v0.1.2 below. User confirmed v0.1.2 works before requesting
these additions. v0.2.0 behavior is **not yet gameplay-tested**; current evidence is
read-only live data plus offline tests. Older implementation descriptions below are historical.

- `analysis/new-build/ground-20260923-224014.json` (held) and
  `ground-20260923-224140.json` (dropped): same Quasar id480/generation346,
  holder468 -> 0; independent Heat and Control still exist, Control index11 < active count12.
- `analysis/new-build/live-ground.json`: production reader + bounded Heat discovery
  successfully resolves the dropped weapon, local avatar, absent firing slots and update membership.
  Test replay uses the saved addresses only as an offline fixture. The live mod always re-resolves.
- `reader.lua` discovery reads Heat total count+16 and entity array+64, up to32 entries
  per call. It does not confuse allocated capacity+12 with live entries. Every candidate
  is independently mapped and guarded before writing. At most8 policies are active.
- `policy.lua` removes witnessed-shot arming; one request after stable non-held idle and
  native cooldown. Verified same-identity local drop/pickup can retain the owned request.
  Native cancellation is respected. No charge, trigger or firing-state field is written.

### Enhanced option identification

FileDiver commit `3e5f5e5` supplies `datalibrary/dl_library.dl_typelib`,
`generated_entities.dl_bin`, and the Projectile/Damage/Explosion struct definitions.
`analysis/offline_projectile_link.py` parses the actual inline component map using that
typelib (not an assumed hash-table offset): resource `0x35a61296619cc47e` maps to
component index245, whose projectile type is133. It is the only nonempty resource using
133 in that offline component table. This is offline association evidence, not a current
runtime component-layout proof.

The current loaded projectile133 has the matching speed1300, mass12, thruster effect
hash4119032866764398427 and dissipate effect hash10519283667786080267; it links to
direct damage383 and explosion67, whose damage type is384. Names alone are insufficient:
multiple laser records share the localization keys. Old damage enum375/376 must not be used.

Current data saved in `analysis/new-build/settings-census.json`, corresponding `.bin`
excerpts, and `enhancement-records.json`. Record strides: projectile272, damage76,
explosion152. The early explosion capture is oversized; only count*152 bytes are rows,
with the remainder excluded from record parsing.

Native pointer maps, indexed by each record's type (not row order):

| Kind | Map RVA | Target |
|---|---|---|
| Projectile | 0x37c7670 | 133 |
| Explosion | 0x37cc920 | 67 |
| Damage | 0x37c60c0 | 383, 384 |

`fragment-11f8c60.txt` / `fragment-11f8cfb.txt` show damage loading:
0x11f8dd6 uses stride0x4c, then stores the row pointer indexed by record type.
`fragment-7d02e7.txt` includes a damage-map consumer at0x7d251c/0x7d2523.
`fragment-75b0b0.txt` includes projectile lookup at0x75b954.
`fragment-11ec5a0.txt`, `fragment-11ec760.txt`, `fragment-11dc320.txt`,
`fragment-11dc4e0.txt` show projectile/explosion map load/clear paths.
The enhanced entry adds `analysis/enhancement-signatures.json` to the fourteen base checks.
`analysis/verify_enhancement.py` re-reads these roots and exact record bytes in the current
session; `enhancement-live-verified.json` records success with zero process writes.

`settings.lua` compares complete damage records, complete projectile record and explosion
record excluding its relocated ShakeAssets pointer at+40..47. It only writes damage383
+4..11 (normal/durable 2000 -> 3200), damage384 +28..31 (demolition30 ->40).
It leaves direct demolition30, explosion damage150/150, radii1.5/3/6 and AP unchanged.
Writes target native map-selected rows, not every same-looking copy. Shared Quasar
settings affect Quasars in the current process, not only the locally carried instance.
Other changes to these records disable the enhancement and trigger conditional cleanup.
Pointer/read failures retain cleanup state; old unloaded-table pointers are not written.
The Windows writer now accepts only these two fixed payloads/reversals plus boolean drive.

### Package and validation

One stable GUID and module; `Options/ChargeOnly` and `Options/Enhanced` contain mutually
exclusive archive variants. The parent manifest uses `SubOptions` per the
[Arsenal manifest schema](https://raw.githubusercontent.com/teutinsa/Helldivers2ModManager/master/mod_manifest_v1-schema.json)
(checked 2026-09-23). Build still uses unchanged upstream `build_addon.py` and archive encoder.
Offline tests cover synthetic state transitions, actual captured reader bytes, exact
setting writes/restores, conflicts, pointer relocation, failures, bounded discovery,
callback behavior, the Windows adapter in Python-owned memory, and both real Loader scans.
No new variant was deployed or gameplay-tested during development. See README for minimal tests.

## v0.1.2 — game update on 2026-09-23

Current target: EXE **1.8.45850.0**, Steam build **25327279**.
EXE SHA256 `d8e23968d1412b07e06785321727d63edf74e711214d6f6adeb3bfca95ca6827`;
game.dll SHA256 `73374bd4e38386beb9a23bef480082b67d457ebc77485fbec5f488b4e95e201f`.
The sections below this update describe the historical v0.1.0/v0.1.1 build.

Updated loaded-code evidence: `analysis/new-build/`. `layout-migration.json`
records each old/new address; the behavior policy and Windows writer are unchanged.

| Component | New root / layout | Evidence |
|---|---|---|
| Mission gate | 0x33266a0; count+8, state+0x40, range1..7 | 380110.txt, 0x38013b–0x380157 |
| Local player | 0x3326468; counts+0x84/+0x88, local unit+0x3a8 | 4b0060.txt; 763750.txt, 0x763e49–0x763e67; read-only ship capture |
| Entity owner | 0x346bf98; unit map **0xf22ec8**, entity array **0xf32f18**, stride24 | fd9ba0.txt; 0xfd9d15–0xfd9d23 computes `(index*3+0x1e65e3)*8` |
| Equipment | 0x3326738; map40, entity pointers64, runtime80/stride48, selector28 | 9a84a0.txt, 9aaa50.txt; read-only ship capture |
| WeaponData | 0x3326ce0; map48, entities72, network96/stride12 | 77f070.txt, 77ead0.txt; runtime identity validation |
| Attachment | 0x3326dc0; map32, runtime64/stride48, holder+4 | 763750.txt |
| Firing states | 0x3326420; map48, entities72, requests88/stride32, runtime96/stride464, states104/stride4 | 785d10.txt, 77e350.txt, update-code-0x77e70e.txt |
| Invalid weapon ID | 0x3483c34 | 7853d0.txt, 0x785829; fd9ba0.txt |
| WeaponControl | 0x3326660; map40, entities64, trigger88, active count24 | 763780.txt, 7417a0.txt, fragment-7406a0.txt |
| Heat | 0x3326d48; map40, entities64, drive72, runtime80/stride72, network88/stride12 | 77f070.txt, 763780.txt, 764970.txt |

Charge remains runtime+12. Heat, overheat and derived request remain network+4/+8/+9.
0x7643de–0x7643ec applies gain and cap using config+0x98/+0x94.
0x77f450 / 0x77f723 set/clear Heat drive. 0x7649dc–0x764a04 derives request
from drive and the native predicate. These are inspected instructions, not function calls from the mod.

Switching at 0x9aabf5 unbinds the old weapon through 0x785d10; 0x9aac0f stores
the new selector; 0x9aaf61 binds the new weapon through 0x785de0.
Teardown at 0x78578d calls stop-state 0x786df0, which calls drive-off 0x77f4c0;
0x785829 loads the invalid ID for the removed record.
The dispatcher 0x77e350 retains the invalid-record skip and separate player request
at 0x77e82b before fire-start 0x7413d0. Readiness at 0x77edb0 compares charge to its threshold.

The main tick calls WeaponControl update at 0x573245, which invokes Heat charge
update at 0x740c75; derived-request update follows at 0x573767.
Other Control runtime flag bits changed in this build; the mod does not access those bits.

The runtime now verifies both new hashes and fourteen exact code excerpts.
The read-only scout's masked search is only a locating aid, never a runtime compatibility bypass.
Ship probing successfully resolved the local unit, avatar identity, equipment and a non-Quasar support record.
`live-ship.json` records only reads requested by the reader and uses a ship-only diagnostic
mission-gate bypass; production keeps its mission gate. No probe includes a process write implementation.
`live-mission.json` additionally captures the user's equipped Quasar in a mission:
identity/holder matched, state present and idle, trigger/drive/request/heat/charge zero,
and Control index inside its update range. The production reader (no gate bypass)
returned a complete snapshot. Tests replay both real captures and confirm that reverting
the entity unit-map offset to the old value rejects the new capture.
This is runtime read verification, not a test of firing or automatic charging.
Full background-charge/fire behavior on the new build still requires the user's in-game test.

## Historical implementation evidence

This experimental module is separate from the unchanged read-only QuasarAutoChargeDebug v0.2.1.

- BingusSharedLoader commit `836427cef78b8a67cf771c1f16291d93be921744`: unchanged `scripts/build_addon.py` / `archive.py` for packaging; actual `src/discover.lua` for package tests. https://github.com/CowboyBingus/BingusSharedLoader
- SentryAimRetention commit `7056c3e9f1d1a83d639e93d70821cdee62c25426`: Windows self-process read/hash/write and VirtualQuery patterns; conditional leases and fresh identity validation in `src/aim_data.lua`. Our adapter restricts writes to one boolean byte, has no native setters or executable writes. https://github.com/CowboyBingus/SentryAimRetention
- ControllableHoverPack commit `38a0d728df57204af37287434fac30eb5846351b`: local avatar, mission, equipment and attachment registry access; callback preservation. https://github.com/CowboyBingus/ControllableHoverPack
- QuasarAutoChargeDebug local verified reader and test traces: charge/heat/drive/control-loop membership.

Local loaded-code evidence is preserved in `../QuasarAutoChargeDebug/analysis/native/`.
No native functions were invoked and no live process memory was written during development.

## Charge and shot separation

`heat_request_region.txt`: Heat manager root RVA 0x276ca58; byte array+0x48, per-entity independent Heat index. Drive is combined with !predicate_0x76f3d0 to produce network+9. Native charge code adds dt*gain and clamps to threshold when network+9 && !overheated; otherwise it decays. The mod only requests this existing logic.

`request_on_complete.txt` / `request_off.txt`: drive set/clear at 0x777030 / 0x777303.
`request_state_start_stop_complete.txt`: state manager root 0x276c148; map+0x30, entity pointers+0x48, local request array+0x58 stride32, runtime+0x60 stride464, packed network states+0x68 stride4. Five runtime records of80 bytes associate each weapon entity with a 3-bit state group and a request byte. Ambiguous/redirection cases are rejected. Runtime cleanup re-resolves maps instead of following cached target addresses.

`firing_state_decision.txt`: state3 plus full charge changes to4; state4 may reach fire-start 0x7397e0. At 0x7763d5 state other than4 takes the non-firing branch; request byte must also be set at 0x77640b. v0.1.0 required a matching slot with state0/request0/trigger0; v0.1.1 also accepts positively verified absence of the holstered weapon from all five records, as explained below. It never calls the original state-start function (which would also set state3 and request1).

This is evidence for the experiment, not proof that no other engine path or animation transition can alter the states. Keeping charge across re-equip and avoiding unintended shots remain runtime acceptance criteria.

## Equipment selector verified on 2026-09-20

`equipment_current_getter.txt`: native 0x99d2f0 returns EquipmentRuntime[index*48+0x1c]; 0x99d3a0 passes that value to 0x9a5ac0 to resolve the selected entity.
`equipment_current_resolve.txt`: the resolver dispatches slots1..6 through a jump table to runtime offsets0,4,8,16,16,12 respectively; zero/unsupported values return0. The matching dispatch at0x6360cf and its table0x636e2c are saved too. Accordingly equipped means the native selected entity equals this Quasar, not animation completion.

WeaponHeat runtime+12 charge and network+4 heat were correlated with actual player tests. 0.2.1 trace at2026-09-20T18:32:58 confirmed control-loop membership remains1 while holstered, but drive/request remain0 after cooldown. This justifies testing one-byte drive activation without changing cooldown or writing charge.

## Bounds

Build hashes and ten native signatures lock the researched version. Snapshot checks are consistency guards, not thread synchronization. Only current local authoritative support Quasar is eligible for activation. Unreadable components and aliases fail closed. On transfer/destruction, the module relinquishes ownership instead of writing into the new owner's state; complete death/drop/network behavior is not runtime-verified.

The only production write API is WriteProcessMemory on the current process, size1, expected boolean value and writable private PAGE_READWRITE memory. No native binaries, injection, input simulation, memory protection changes, game-function bindings or resource parameter patches are packaged.

## v0.1.1: native switch unbinds the old weapon

The real v0.1.0 session at2026-09-20T19:52:29 recorded `ARM` at119.719s, `quasar_state_slot_missing` from120.782s through holster, and a readable Quasar slot again at160.094s. Final activation_writes=0. The old reader aborted before reading Heat during holster. This is evidence of a reader/policy blocker, not a failed native charging experiment.

Local loaded code was inspected read-only on2026-09-21; targeted excerpts are in this project's `analysis/`:

- `equipment_switch_binding.txt`: 0x99f710 reads old equipment selector+28 at0x99f7e7; 0x99f8c4 calls0x77d760 to remove the old entity, then0x99f8da stores the new selector. 0x99fc31 calls0x77d830 with the selected replacement entity and reusable state slot.
- `state_registration_candidates.txt` includes0x77d760: looks for old entity among five stride80 records;0x77d821 invokes0x77d660 with its slot. Early misaligned candidate lines are not used as evidence.
- `state_slot_remove.txt`: 0x77d6e4 calls0x77ce20.
- `state_slot_teardown.txt`: 0x77d053 stops fire control,0x77d1dd invokes state stop0x77e840 (which clears Heat drive), then0x77d286 replaces the slot entity with the invalid sentinel. Thus missing old entity is an expected result of native unbinding.
- `state_slot_bind.txt`: 0x77d8e6 tears down the slot,0x77d90a writes the new weapon ID. No registration changes are made by this mod.
- `state_dispatch_prolog.txt`, valid entry0x775f30: 0x776025 reads the selected record's entity;0x77602b skips invalid entries before the firing decision. Subsequent logic follows that entity or the record redirect. Checking every record's base and redirect ensures the absent Quasar is not accidentally confused with the active primary's state. This is evidence for the bounded experiment, not a universal proof about all other firing paths.

v0.1.1 returns `state_presence=absent`, nil state/input/slot, and the actual independent Heat/Control values when all five records were fully read and neither their base IDs nor redirects match Quasar. It does not turn a failed read into absence, reuse the old slot, or write any actor state. Activation requires a positively identified different equipped item, same local holder/weapon generation, trigger0, native cooldown complete and stable0.25s. All record identities, pointers and map rows are rechecked immediately before writing. Returning to Quasar re-resolves its potentially different state slot before native handoff.

Regression tests cover the observed removal/replacement/reappearance sequence, another weapon actively using the old slot, late base/redirect reappearance, incomplete scans, rebind to a different slot, and cleanup while absent. These tests use synthetic memory: background charge growth and actual next-shot behavior still require gameplay verification.
