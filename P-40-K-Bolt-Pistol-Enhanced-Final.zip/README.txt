P/40-K Bolt Pistol Enhanced

Direct Hit
- Damage: 325 -> 400
- Durable Damage: 115 -> 250
- Demolition Force: 20 -> 30

Explosion
- Damage: 175 (unchanged)
- Durable Damage: 175 (unchanged)
- Demolition Force: 10 -> 30

Standalone final release.
Routine scan-progress logging has been removed; useful patch/error diagnostics are retained.
