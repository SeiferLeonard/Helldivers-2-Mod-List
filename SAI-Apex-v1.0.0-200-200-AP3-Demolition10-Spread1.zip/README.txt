SAI Apex v1.0.0 - 200/200 / AP3 / Demolition 10 / Spread 1/1

Built directly from the confirmed working Dagger + SAI Apex v1.5.1 baseline.
SAI only: 200 standard damage, 200 durable damage, AP3, demolition strength 10, spread 1/1.
Projectile velocity is intentionally untouched. Recoil is intentionally untouched.
Dagger resource and source have been removed. No future-proofing has been added in this version.
