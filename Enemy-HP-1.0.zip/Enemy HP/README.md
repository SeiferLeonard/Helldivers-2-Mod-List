# Enemy HP

See the health of what you mark. When you mark an enemy with the ping key (the red marker with a name), Enemy HP shows
its current and maximum health just under the marker:

    Bile Titan  -  2073 / 6500  (32%)

- The label follows the enemy and updates live while you fight it.
- It lasts exactly as long as the game's mark: normal marks fade after 8 seconds, multi-marks stay until you cancel
  them (ping the enemy again) or the enemy dies. When a marked enemy dies you briefly see "killed".
- The colour follows the game's own ping class: red for enemies, white for vehicles, turrets and gear,
  yellow for objectives, orange for mines and explosive barrels. Mark your own FRV to see its health too.
- White location pings and your teammates' marks are ignored.

## Requirements

- **Bingus Shared Loader** v15 or newer (API 1).
- Game build **Steam 25480438** (game version 1.8.46015.0). The mod checks the game build when it starts. On any
  other build it switches itself off and writes "unsupported game version" to its log. It never shows wrong data
  after a game update; it waits for an update of the mod instead.

## Install

1. Install and enable Bingus Shared Loader.
2. Import `Enemy-HP-1.0.zip` in your mod manager and enable it.
3. Deploy, then start the game.

## Settings

`%LOCALAPPDATA%\Hd2EnemyHp\enemy_hp.cfg` (created on first run):

    offset=-40

`offset` is the label position in pixels relative to the marked point. Negative moves it down, positive moves it up.
Changes apply at the next game start.

## Log

`%LOCALAPPDATA%\Hd2EnemyHp\EnemyHp.log`: one line per mark, with the enemy's name, health and mark type. Newer enemy
types without a name show as "Target"; their log line includes the type id.

## How it works / safety

Enemy HP only **reads** game memory: the game's list of active pings, the health data, and unit positions. It writes
nothing to the game, sends nothing over the network and does not change any gameplay values. It is client-side only;
other players do not need it and are not affected.

## Credits

The layout of the game's ping list was found by etxp in the open-source HD2 G-60 Smart Targeting mod. Thank you!
